﻿var iconn = document.getElementById('iconnection');
var iindex = iconn.value;
iconn.addEventListener('change', (event) => {
    if (iconn.value != iindex)
    {
        swal({
            title: "User Attention",
            text: "Ensure you are selecting the correct installation connection type.\r\nOn submit, if exist, all points and energy meters will be deleted.\n\r\n\r",
            icon: "warning",
            buttons: true,            
        })
        .then((willDelete) => {
            if (willDelete) {
                swal("Remember to create points and energy analyzers after submit.", {
                    icon: "success",
                });
            } 
        });
    }
});

