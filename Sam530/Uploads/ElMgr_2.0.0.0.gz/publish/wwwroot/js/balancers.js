﻿"use strict";

import { formatDate } from './dates.js';

var connection = new signalR.HubConnectionBuilder().withUrl("/netpointHub").build();

connection.on("BalancerChanges", function (balancer) {
    /*console.log("Balancer Has Changed");
    console.log(balancer);*/

    try {

        var t = document.getElementById(balancer.setup.name);
        if (t == null)
        {
            //console.log("Balancer NOT FOUND " + balancer.setup.name)
            return;
        }
        var r = t.rows[1];
        var c = r.cells;
        

        c[0].innerHTML = balancer.balanceablePower;
        c[1].innerHTML = balancer.grantedPower;
        c[2].innerHTML = balancer.realSuppliedPower;
        c[3].innerHTML = balancer.unmanagedPower;

        
        //balancer.balancedPoints.forEach(function (cp) {
            balancer.connectors.forEach(function (co) {
                var r = document.getElementById(co.setup.id);
                var c = r.cells;

                if (co.isCharging) {
                    c[1].innerHTML = co.energyBucket.pilotPower;
                    c[2].innerHTML = co.energyBucket.consumedPower;
                    c[3].innerHTML = co.energyBucket.stateDescription;
                    if (co.energyBucket.stateDescription!="UNKNOWN")
                        c[4].innerHTML = formatDate(co.energyBucket.stateTimestamp);
                    else
                        c[4].innerHTML = '--';
                }
                else {
                    c[1].innerHTML = '--';
                    c[2].innerHTML = '--';
                    c[3].innerHTML = '--';
                    c[4].innerHTML = '--';
                }

            });            
            
        //});

        //Contratada
        var Cont = document.getElementById(balancer.setup.name + "Cont");
        Cont.innerHTML = balancer.availablePower;

        //Building
        var Cons = document.getElementById(balancer.setup.name + "Cons");
        Cons.innerHTML = balancer.buildingPower;

        //Solar
        var Sola = document.getElementById(balancer.setup.name + "Sola");
        Sola.innerHTML = balancer.solarPower;


        var tit = document.getElementById(balancer.setup.name + "title");
        if (balancer.canBalance==true) //Is Balancing
            tit.className = "table-success";
        else
            tit.className = "table-default";

        var MeterError = false;

        var stBuilding = document.getElementById(balancer.setup.name + "BMeter");
        if ((balancer.buildingMeterState != null) && (stBuilding!=null)) {
            if (balancer.buildingMeterState.isTimeout) {
                stBuilding.innerHTML = "Error (Timeout)"
                //stBuilding.className = "table-danger table-bordered";
                MeterError = true;
            }
            else
            {
                stBuilding.innerHTML = "Ready"
                //stBuilding.className = "table-default";
            }

        }

        var stSolar = document.getElementById(balancer.setup.name + "SMeter");
        if ((balancer.solarMeterState != null)&&(stSolar!=null)){
            if (balancer.solarMeterState.isTimeout) {
                stSolar.innerHTML = "Error (Timeout)"
                //stSolar.className = "table-danger table-bordered";
                MeterError = true;
            }
            else {
                stSolar.innerHTML = "Ready"
                //stSolar.className = "table-default";
            }
        }

        var Met = document.getElementById(balancer.setup.name + "Meters");
        if (MeterError == true) //Is Balancing
            Met.className = "table-danger";
        else
            Met.className = "table-success";

        

    }
    catch (error) {
        console.error(error);
    }

});

connection.on("ConnectorChanges", function (co) {
    console.info("Connector Changes");
    var r = document.getElementById(co.setup.id);

    if (r == null) return; //Connector not found

    var c = r.cells;

    

    if (co.isCharging) {
        c[1].innerHTML = co.energyBucket.pilotPower;
        c[2].innerHTML = co.energyBucket.consumedPower;
        c[3].innerHTML = co.energyBucket.stateDescription;
        c[4].innerHTML = formatDate(co.energyBucket.stateTimestamp);
    }
    else {
        c[1].innerHTML = '--';
        c[2].innerHTML = '--';
        c[3].innerHTML = '--';
        c[4].innerHTML = '--';
    }
    
});


connection.start().then(function () { console.log("Connected to Hub"); })