﻿"use strict";

import { formatDate } from './dates.js';

var connection = new signalR.HubConnectionBuilder().withUrl("/netpointHub").build();

connection.on("MeterChanges", function (meter) {

    try {

        var t = document.getElementById(meter.setup.address);
        if (t == null)
        {
            return;
        }
                
        var c = t.cells;
        
        if (meter.isTimeOut) {
            c[3].innerHTML = "Error";
            c[4].innerHTML = "Error";
            c[5].innerHTML = "Error";
        }
        else {
            c[3].innerHTML = meter.phase1.current;
            c[4].innerHTML = meter.phase2.current;
            c[5].innerHTML = meter.phase3.current;
        }

    }
    catch (error) {
        console.error(error);
    }

});


connection.start().then(function () { console.log("Connected to Hub"); })