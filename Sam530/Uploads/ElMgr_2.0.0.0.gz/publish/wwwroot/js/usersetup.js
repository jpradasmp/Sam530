﻿var myData;

function testSFTP() {
    return fetch('./UserSetup/Index?handler=TestSFTP',
        {
            method: 'get',
            headers: {
                'Content-Type': 'application/json;charset=UTF-8'
            }
        })
        .then(function (response) {
            if (response.ok) {
                return response.text();
            } else {
                throw Error('Response Not OK');
            }
        })
        .then(function (text) {
            try {
                return JSON.parse(text);
            } catch (err) {
                //console.error('Method Not Found');
            }
        })
        .then(function (responseJSON) {
            myData = responseJSON;           
            if (myData.IsSuccessfull==true) {                
                swal("SFTP Successull", "Sending file completed without errors", "success")
            }
            else {                
                swal("SFTP Error", myData.TransactionError, "error")
            }
        })
}
