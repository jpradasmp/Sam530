﻿"use strict";

var connection = new signalR.HubConnectionBuilder().withUrl("/netpointHub").build();

connection.on("NetpointsStatusChanges", function (np) {
    console.info("Netpoints Changes");
    var r = document.getElementById(np.setup.ip);
    var c = r.cells;
    var ii = document.getElementById(np.setup.ip + 'iconinfo');
    var iw = document.getElementById(np.setup.ip + 'iconwarn');

    if (np.state.status == 2) 
        r.className = "table-danger";
    else
        r.className = "table-default";

    if (np.state.status != 2) {
        c[3].innerHTML = np.state.pointsOnCharge + '/' + np.state.totalPoints;
        c[4].innerHTML = np.state.grantedPower;
        c[5].innerHTML = np.state.consumedPower;

        try {
            iw.setAttribute("class", "feather-hide");
            ii.setAttribute("class", "feather-32");
        }
        catch (err)
        {
            console.log(err);
        }

    }
    else {
        c[3].innerHTML = np.state.pointsOnCharge + '/' + np.state.totalPoints;
        c[4].innerHTML = np.state.grantedPower;
        c[5].innerHTML = 'Communication Error';
        try {
            ii.setAttribute("class", "feather-hide");
            iw.setAttribute("class","feather-32");
        }
        catch (err)
        {
            console.log(err);
        }
    }


    
});

connection.on("MasterInstallationChanges", function (mi) {

    var gm = document.getElementById('globalMeters');
    var gmh = document.getElementById('globalMetersHeader');

    var cls = gm.cells;
    cls[0].innerHTML = mi.availablePower;
    cls[1].innerHTML = mi.buildingPower;
    cls[2].innerHTML = mi.balanceablePower;
    if (mi.spl.error != "") {
        cls[3].innerHTML = mi.spl.error;
        gmh.className = "table-danger";
    }
    else {
        cls[3].innerHTML = mi.spl.value;
        if (mi.spl.isConnected)
            gmh.className = "table-success";
        else
            gmh.className = "table-default";
    }


});


connection.start().then(function () { console.log("Connected to Hub"); })