﻿"use strict";


var intervalId = window.setInterval(function () {
    /// call your function here
    window.clearInterval(intervalId);
    var root = location.protocol + '//' + location.host+"/Errors";
    window.location.replace(root);
}, 5000);