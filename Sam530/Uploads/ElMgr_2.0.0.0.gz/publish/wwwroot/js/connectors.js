﻿"use strict";

var connection = new signalR.HubConnectionBuilder().withUrl("/netpointHub").build();

connection.on("ConnectorStatusChanges", function (co) {
    console.info("Connector Changes");
    var r = document.getElementById(co.setup.id);
    var c = r.cells;
    var ii = document.getElementById(co.setup.id + 'iconinfo');
    var iw = document.getElementById(co.setup.id + 'iconwarn');


    if (co.busConnection != 2) {
        c[3].innerHTML = 'Unknown';
        c[4].innerHTML = 'Communication Error';
    }
    else
    {
        c[3].innerHTML = co.statusDescription;
        c[4].innerHTML = co.errorCodeDescription;
    }

    switch (co.ocppServerConnection)
    {
        case 0:
            c[5].innerHTML = '--';
            break;
        case 1:
            c[5].innerHTML = 'Disconnected';
            break;
        case 2:
            c[5].innerHTML = 'Connected';
            break;
    }

    if ((co.errorCode != 6) || (co.busConnection != 2)) { //Status!=NoError or Bus NotConnected
        r.className = "table-danger";
        ii.setAttribute("class", "feather-hide");
        iw.setAttribute("class", "feather-32");
    }
    else {
        r.className = "table-default";
        ii.setAttribute("class", "feather-32");        
        iw.setAttribute("class", "feather-hide");        
    }

    
});


connection.start().then(function () { console.log("Connected to Hub"); })