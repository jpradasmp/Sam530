"use strict";


var intervalId = window.setInterval(function () {
    /// call your function here
    var pb = document.getElementById("pbwait");
    if (pb.value < 90) pb.value += 1;
    else {
        window.clearInterval(intervalId);
        var root = location.protocol + '//' + location.host;
        window.location.replace(root);
    }
}, 1000);