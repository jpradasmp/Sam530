﻿function formatDate(jsonDate, hour=true) {
    try {
        var myDate = new Date(jsonDate);

        if (hour)
            return myDate.getUTCDate().toString().padStart(2, "0") + "-" + (myDate.getUTCMonth() + 1).toString().padStart(2, "0") + "-" + myDate.getUTCFullYear() + " " + myDate.getUTCHours().toString().padStart(2, "0") + ":" + myDate.getUTCMinutes().toString().padStart(2, "0") + ":" + myDate.getUTCSeconds().toString().padStart(2, "0")
        else
            return myDate.getUTCDate().toString().padUTCStart(2, "0") + "-" + (myDate.getUTCMonth() + 1).toString().padStart(2, "0") + "-" + myDate.getUTCFullYear();
    }
    catch (err) {
        console.log(err)
    }

}

function formatCurrentDate() {
    return formatDate(new Date().toJSON(),false);
}

export { formatDate, formatCurrentDate };