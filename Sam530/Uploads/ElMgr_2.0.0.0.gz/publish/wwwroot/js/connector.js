﻿"use strict";

import { formatDate, formatCurrentDate } from './dates.js';

//activeConnector must be defined from RazorPage

var createChart=true;
var myData;
var connection = new signalR.HubConnectionBuilder().withUrl("/netpointHub?token=" + activeConnector).build();
var energyChart;
var transChart;


connection.on("ConnectorStatusChanges", function (co) {
    console.info("Connector Changes");
    var r = document.getElementById(co.setup.id);
    if (r != null) {        
        if (co.busConnection == 2) //Connected
        {
            var s = document.getElementById('status');
            s.innerHTML = co.statusDescription;

            var e = document.getElementById('errorCode');
            e.innerHTML = co.errorCodeDescription;

            if (co.chargingFrom != null)
            {
            var f = document.getElementById('chargingFrom');
            f.innerHTML = formatDate(co.chargingFrom);
            }

            if (co.chargingEnd != null)
            {
                var t = document.getElementById('chargingEnd');
                t.innerHTML = formatDate(co.chargingEnd);

                if (co.transactionId > 0) {
                    var tt = document.getElementById("tbtransactions").rows;
                    if ((tt.length > 1) && (tt[1].cells[0].innerHTML == co.transactionId)) {
                        tt[1].cells[3].innerHTML = formatDate(co.chargingEnd);
                        tt[1].cells[4].innerHTML = co.energy;
                    }
                    else { //Must add the new transactions row

                        var tbodyRef = document.getElementById('tbtransactions').getElementsByTagName('tbody')[0];

                        // Insert a row at the end of table
                        var newRow = tbodyRef.insertRow(0);

                        // Add cells data
                        var newCell = newRow.insertCell();
                        var newText = document.createTextNode(co.transactionId); newCell.appendChild(newText);
                        newCell = newRow.insertCell();
                        newText = document.createTextNode(co.tag); newCell.appendChild(newText);
                        newCell = newRow.insertCell();
                        newText = document.createTextNode(formatDate(co.chargingFrom)); newCell.appendChild(newText);
                        newCell = newRow.insertCell();
                        newText = document.createTextNode(formatDate(co.chargingEnd)); newCell.appendChild(newText);
                        newCell = newRow.insertCell();
                        newText = document.createTextNode(co.energy); newCell.appendChild(newText);
                        
                    }
                }
            }
            
            var u = document.getElementById('tag');
            u.innerHTML = co.tag;

            var en = document.getElementById('energy');
            en.innerHTML = co.energy;


            var ip = document.getElementById('instantpower');
            ip.innerHTML = co.instantPower;


            var r = document.getElementById('nocomm');
            r.className = "alert alert-danger div-hide";



        }
        else
        {
            var r = document.getElementById('nocomm');
            r.className = "alert alert-danger div-show";

            var s = document.getElementById('status');
            s.innerHTML = 'Unknown';

            var e = document.getElementById('errorCode');
            e.innerHTML = 'Communication Error';
                        
        }

        var o = document.getElementById('occpconn');
        switch (co.ocppServerConnection) {
            case 0:
                o.innerHTML = '--';
                break;
            case 1:
                o.innerHTML = 'Disconnected';
                break;
            case 2:
                o.innerHTML = 'Connected';
                break;
        }




        getChartData();    

        
    }
   
});



function createEnergyChart() {
    var myValues = myData.ValueList; //[10,20,30,35,35];
    var mySamples = myData.SampleList; //['S1', 'S2', 'S3', 'S4', 'S5']

    let popCanvasName = document.getElementById("currentChart");
    energyChart = new Chart(popCanvasName, {
        type: 'line',
        data: {
            labels: mySamples,
            datasets: [{
                label: 'Energy',
                data: myValues,
                borderColor: [
                    'rgba(255, 99, 132, 0.6)'
                ],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.6)'
                ],
                fill: true
            }]
        },
        options: {
            plugins: {
                legend: {
                    display: false,
                    position: 'right'
                }
            },
            responsive: false,
            scales: {
                y: {                    
                    ticks: {
                        beginAtZero: true
                    },
                    title: {
                        display: true,
                        text: 'Wh'
                    }
                }
            }
        }
    });
}

function createTransChart() {
    var myValues = myData.HValueList; //[10,20,30,35,35];
    var mySamples = myData.HSampleList; //['S1', 'S2', 'S3', 'S4', 'S5']

    let popCanvasName = document.getElementById("histChart");
    transChart = new Chart(popCanvasName, {
        type: 'bar',
        data: {
            labels: mySamples,
            datasets: [{
                label: 'Energy',
                data: myValues,
                borderColor: [
                    'rgba(255, 99, 132, 0.6)'
                ],
                backgroundColor: [
                    'rgba(255, 99, 132, 0.6)',
                    'rgba(132, 99, 255, 0.6)',
                    'rgba(132, 99, 255, 0.6)',
                    'rgba(132, 99, 255, 0.6)',
                    'rgba(132, 99, 255, 0.6)',
                    'rgba(132, 99, 255, 0.6)',
                    'rgba(132, 99, 255, 0.6)',
                    'rgba(132, 99, 255, 0.6)',
                    'rgba(132, 99, 255, 0.6)',
                    'rgba(132, 99, 255, 0.6)'
                ],
                fill: true
            }]
        },
        options: {
            plugins: {
                legend: {
                    display:false,
                    position:'right'
                }
            },
            responsive: false,
            scales: {
                y: {
                    ticks: {
                        beginAtZero: true
                    },
                    title: {
                        display: true,
                        text: 'Wh'
                    }
                }
            }
        }
    });
}


function updateEnergyChart()
{
    var from = energyChart.data.datasets[0].data.length;
    var to = myData.ValueList.length;
    var i = 0;

    if (to < from) {
        energyChart.data.datasets[0].data = [];
        energyChart.data.labels = [];
        from = 0;
    }
    
    
    if (from < to) {
        for (i = from; i < to; i++) {
            energyChart.data.datasets[0].data.push(myData.ValueList[i]);
            energyChart.data.labels.push(myData.SampleList[i]);
        }
    }


    for (i= 0; i < to; i++) {
        energyChart.data.datasets[0].data[i] = myData.ValueList[i];
        energyChart.data.labels[i] = myData.SampleList[i];
    }

    energyChart.update();
    

    
}

function updateTransChart() {
   
    var from = transChart.data.datasets[0].data.length;
    var to = myData.HValueList.length;
    var i = 0;

    if (from < to) {
        for (i = from; i < to; i++) {
            transChart.data.datasets[0].data.push(myData.HValueList[i]);
            transChart.data.labels.push(myData.HSampleList[i]);
        }
    }

    for (i = 0; i < myData.HValueList.length; i++)
        transChart.data.datasets[0].data[i] = myData.HValueList[i];

    transChart.update();    
}



function getChartData() {
    return fetch('./State/Index?handler=UpdateEnergy&id=' + activeConnector,
        {
            method: 'get',
            headers: {
                'Content-Type': 'application/json;charset=UTF-8'
            }
        })
        .then(function (response) {
            if (response.ok) {
                return response.text();
            } else {
                throw Error('Response Not OK');
            }
        })
        .then(function (text) {
            try {
                return JSON.parse(text);
            } catch (err) {
                //console.error('Method Not Found');
            }
        })
        .then(function (responseJSON) {
            myData = responseJSON;

            //Adjust legends
            /*var i;
            var gap = Math.ceil(myData.SampleList.length/ 6);
            if (gap == 0) gap = 1;
            var gapIndex = 0;

            for (i = 0; i < myData.SampleList.length; i++){
                if (i != gapIndex)
                    myData.SampleList[i] = "";
                else
                    gapIndex += gap;

            }*/

            if (createChart) {
                createChart = false;
                createEnergyChart();
                createTransChart();
            }
            else {
                updateEnergyChart();
                updateTransChart();
            }
        })
}



connection.start().then(function () { console.log("Connected to Hub"); })
getChartData();
//showChart();
