#!/bin/bash
cd /home/selba/netcore/netpoint/
tar -czvf diagnostic.gz -C Diag .
sync
