#!/bin/bash
cd /home/selba/netcore/netpoint/
mkdir /home/selba/netcore/netpoint/updfiles
sudo rm -r /home/selba/netcore/netpoint/updfiles/*
sudo tar -xvzf /home/selba/netcore/netpoint/EMFiles.gz -C ./updfiles
sudo rm  /home/selba/netcore/netpoint/EMFiles.gz
sync
