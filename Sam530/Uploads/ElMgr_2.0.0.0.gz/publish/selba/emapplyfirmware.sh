#!/bin/bash
#!/bin/bash
file="/home/selba/netcore/netpoint/publish/NetpointWeb.dll"
if [ ! -f "$file" ]
then
	echo "$0: File '${file}' not found."
else
    cd /home/selba/netcore/netpoint
    sudo cp -r /home/selba/netcore/netpoint/publish/* ./web 
    sudo cp -r /home/selba/netcore/netpoint/publish/selba/* . 
    sudo rm -r /home/selba/netcore/netpoint/publish
    sync
    echo "Firmware Updated"
fi



