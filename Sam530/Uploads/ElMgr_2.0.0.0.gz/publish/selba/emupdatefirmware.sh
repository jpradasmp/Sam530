#!/bin/bash
cd /home/selba/netcore/netpoint/
sudo rm -r /home/selba/netcore/netpoint/publish
sudo tar -xvzf /home/selba/netcore/netpoint/EMFirmware.gz
sudo rm  /home/selba/netcore/netpoint/EMFirmware.gz
sync
